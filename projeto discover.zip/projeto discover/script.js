function mudarLuz(){

    const html = document.documentElement
    const img = document.getElementById("perfil")
    const background = document.getElementById("bodyback")



    if(html.classList.contains('light')){

        html.classList.remove('light')
        img.setAttribute('src','Assets/perfil.png')
        background.setAttribute(background)



    }else{


        html.classList.add('light')
        img.setAttribute('src','Assets/perfilbranco.png')


    }


}